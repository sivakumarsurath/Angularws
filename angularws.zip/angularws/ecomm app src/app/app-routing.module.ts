import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductlistComponent } from './products/productlist.component';
import { ProductsearchComponent } from './products/productsearch.component';

const routes: Routes = [
  {path:"SearchForm",component:ProductsearchComponent},
  {path:"ProductList",component:ProductlistComponent},
  {path:"",component:ProductsearchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
