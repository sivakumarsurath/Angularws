import { Component, OnInit } from '@angular/core';
import { Iproduct } from './product.interface';
import { ProductService } from './product.service';

@Component({
  selector: 'app-productsearch',
  templateUrl: './productsearch.component.html',
  styleUrls: ['./productsearch.component.css']
})
export class ProductsearchComponent implements OnInit {
  
  searchTerm:string;
  searchTerm1:string;
  products:Iproduct[];

  
  constructor(private productService:ProductService) { }
 
  
  searchProduct(){
    this.searchTerm=this.searchTerm1;
  }


  ngOnInit() {
    if(this.productService.getData()){
    this.products=this.productService.getData();
  }
 
  else{
      this.productService.getProducts().subscribe((data)=>
      {
        this.products=data;
        this.productService.setData(this.products);
      },(error)=>{console.log(error);});
  }
}
}
