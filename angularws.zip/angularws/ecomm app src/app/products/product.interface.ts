
export interface Iproduct{
    id:string;
    name:string;
    price:number;
    category:string;
}