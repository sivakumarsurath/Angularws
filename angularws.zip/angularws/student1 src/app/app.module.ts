import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentListComponent } from './student1/student-list/student-list.component';
import { AddStudentComponent } from './student1/add-student/add-student.component';
import { StartpageComponent } from './student1/startpage/startpage.component';
import { HttpClientModule } from "@angular/common/http";
import { StudentService } from './student1/student.service';

@NgModule({
  declarations: [
    AppComponent,
    StudentListComponent,
    AddStudentComponent,
    StartpageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule

  ],
  providers: [StudentService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
