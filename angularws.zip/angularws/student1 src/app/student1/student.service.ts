import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { Student } from '../student';
 
@Injectable({
 providedIn: 'root'
})
export class StudentService implements OnInit {
students:Student[];
 constructor(private http:HttpClient) { }
 ngOnInit(){
 
 }
 getStudents():Observable<Student[]>{
 return this.http.get<Student[]>("../../assets/students.json");
 }
}