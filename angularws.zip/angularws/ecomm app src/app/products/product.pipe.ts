import { Pipe, PipeTransform } from '@angular/core';
import { Iproduct } from './product.interface';

@Pipe({
  name: 'product'
})
export class ProductPipe implements PipeTransform {


  
  transform(products:Iproduct[],searchTerm:string): any {
    
    searchTerm=searchTerm.toLowerCase();
    return products.filter(
      product=>(product.id.toString()==searchTerm
      ||product.name.toLowerCase().startsWith(searchTerm)
      ||product.price.toString()==searchTerm
      ||product.category.toLowerCase().startsWith(searchTerm)));
  }

}
