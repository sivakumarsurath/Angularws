import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowSearchedDataComponent } from './show-searched-data.component';

describe('ShowSearchedDataComponent', () => {
  let component: ShowSearchedDataComponent;
  let fixture: ComponentFixture<ShowSearchedDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowSearchedDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowSearchedDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
