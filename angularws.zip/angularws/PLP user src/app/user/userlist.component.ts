import { Component, OnInit } from '@angular/core';
import { User } from '../model/user.interface';
import { UserService } from './user.service';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserlistComponent implements OnInit {
  users: User[];
  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.getAllUsers().subscribe((data: User[]) => { this.users = data });
  }

  deleteUser(user: User) {
    if (window.confirm("Are you sure you want to delete the user with id " + user.id)) {
      this.userService.deleteUser(user).subscribe((data) => { this.users = this.users.filter(c => c !== user) });
    }
  }
}
