import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/model/customer';
import { CustomerService } from 'src/app/service/customer.service';

@Component({
  selector: 'app-customerlist',
  templateUrl: './customerlist.component.html',
  styleUrls: ['./customerlist.component.css']
})
export class CustomerlistComponent implements OnInit {
customers:Customer[];
name:string="sivakumar";
dob=new Date(1997,12,23);
salary=35000.2288;

  constructor(private customerService:CustomerService) { }

  ngOnInit() {

    this.customerService.getAllCustomers().subscribe(
      (data:Customer[])=>{this.customers=data;
      console.log("all"+this.customers)});
  }
  deletecustomer(customer:Customer){
    this.customerService.deleteCustomer(customer).subscribe(
      (data)=>{this.customers=this.customers.filter(c=>c!==customer)}
    );
    
  }
}
