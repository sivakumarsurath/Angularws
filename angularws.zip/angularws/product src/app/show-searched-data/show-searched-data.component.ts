import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-searched-data',
  templateUrl: './show-searched-data.component.html',
  styleUrls: ['./show-searched-data.component.css']
})
export class ShowSearchedDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
