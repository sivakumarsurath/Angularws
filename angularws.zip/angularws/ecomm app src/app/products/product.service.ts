import { Injectable } from '@angular/core';
import { Iproduct } from './product.interface';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from '../../../node_modules/rxjs';
import {catchError} from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  products: Iproduct[];


  constructor(private http:HttpClient) { }
  
 

  getProducts():Observable<Iproduct[]>{
    return this.http.get<Iproduct[]>("./assets/db.json").pipe(catchError(this.handleError));
  }

 
  getData(){
    return this.products;
  }

  
  setData(productsData:Iproduct[]){
    this.products=productsData;
    //console.log(this.products);
  }

  
  deleteProduct(product:Iproduct){
    let index=this.products.indexOf(product);
    this.products.splice(index,1);
  }

   
  handleError(errorResponse:HttpErrorResponse){
    if(errorResponse.error instanceof ErrorEvent){
      console.log("clent side error",errorResponse);
    }
    else{
      console.log("server side error",errorResponse);
    }
    return throwError("something wrong, please try again");
  }

  
}