import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentListComponent } from './student1/student-list/student-list.component';
import { AddStudentComponent } from './student1/add-student/add-student.component';
import { StartpageComponent } from './student1/startpage/startpage.component';


const routes: Routes = [


{path:'students', component:StudentListComponent},
{path:'add', component:AddStudentComponent},

{path:'', component:StartpageComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
