import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { ProductlistComponent } from './products/productlist.component';
import { ProductsearchComponent } from './products/productsearch.component';
import { ProductPipe } from './products/product.pipe';
@NgModule({
  declarations: [
    AppComponent,
    ProductlistComponent,
    ProductsearchComponent,
    ProductPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
