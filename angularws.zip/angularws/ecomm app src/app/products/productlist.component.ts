import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service';
import { Iproduct } from './product.interface';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {
products:Iproduct[];

  constructor(private productService:ProductService) { }


  ngOnInit() {
    this.productService.getProducts().subscribe((data) => {this.products = data;
     this.productService.setData(this.products);
    }, (error) => console.log(error));
  }

  

    deleteProduct(product:Iproduct){
      this.productService.deleteProduct(product);
    }
   

}
